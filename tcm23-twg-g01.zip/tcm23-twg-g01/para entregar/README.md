Technews
Repositório para projeto da cadeira de Tecnologias Web, da Universidade da Maia. Desenvolvido por @Beatriz043545, @Ritanunes7 e @luenamp.

Descrição
O site aborda uma temática de várias notícias sobre tecnologias.

Tecnologias
Para este projeto utilizamos as seguintes tecnologias:
HTML, CSS, JavaScript, XML e XSD.

Grupo
Beatriz @Beatriz043545
Rita @Ritanunes7
Luena @luenamp
